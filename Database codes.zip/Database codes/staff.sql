-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2016 at 11:33 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `insuranceType` varchar(50) NOT NULL,
  `dateOfBirth` varchar(50) NOT NULL,
  `phone_number` int(30) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `specialization` varchar(200) NOT NULL,
  `staffPatient_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `username`, `firstname`, `lastname`, `gender`, `insuranceType`, `dateOfBirth`, `phone_number`, `nationality`, `email`, `specialization`, `staffPatient_id`) VALUES
('STF09871', 'john.asiedu', 'John', 'Asiedu', 'Male', 'MED X', '1982/09/08', 246538567, 'Ghanaian', 'john.asiedu@ashesi.edu.gh', 'Hostel Management ', NULL),
('STF12345', 'joseph.husein', 'Joseph', 'Husein', 'Male', 'NHIS', '1980/09/08', 541236578, 'Ivorian', 'joseph.husein@ashesi.edu.gh', 'Security Man', NULL),
('STF23456', 'casper.annie', 'Casper', 'Annie', 'Male', 'MED X', '1881/09/07', 543567890, 'Ghanaian', 'casper.annie@ashesi.edu.gh', 'Operations Management', NULL),
('STF32145', 'joanna.ansah', 'Joanna', 'Ansah', 'Female', 'MED X', '1890/05/03', 207855433, 'Ghanaian', 'joanna.ansah@ashesi.edu.gh', 'Cleaning Lady', NULL),
('STF89054', 'felicia.owusu', 'Felicia', 'Owusu', 'Female', 'NHIS', '1987/09/01', 546734562, 'Ghanaian', 'felicia.owusu@ashesi.edu.gh', 'Hostel Management ', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
