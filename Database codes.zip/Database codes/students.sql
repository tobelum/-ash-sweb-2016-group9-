-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2016 at 11:33 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `student_id` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `insuranceType` varchar(50) NOT NULL,
  `dateOfBirth` varchar(50) NOT NULL,
  `phone_number` int(30) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `class` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `studentPatient_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `username`, `firstname`, `lastname`, `gender`, `insuranceType`, `dateOfBirth`, `phone_number`, `nationality`, `class`, `email`, `studentPatient_id`) VALUES
(12092017, 'tobel.eze-okoli', 'Tobel', 'Eze-Okoli', 'Female', 'MED X', '1995/09/06', 236789456, 'Nigerian', 2017, 'tobel.eze-okoli@ashesi.edu.gh', NULL),
(12432018, 'harriet.mlwanda', 'Harriet', 'Mlwanda', 'Female', 'MED X', '1995/09/09', 264539123, 'Zimbabwean', 2018, 'harriet.mlwanda@ashesi.edu.gh', NULL),
(15622019, 'susan.kenyatta', 'Susan', 'Kenyatta', 'Female', 'MED X', '1995/09/05', 208114397, 'Kenyan', 2019, 'susan.kenyatta', NULL),
(19082019, 'usher.raymond', 'Usher', 'Raymond', 'Male', 'MED X', '1995/09/08', 548798765, 'American', 2019, 'usher.raymond@ashesi.edu.gh', NULL),
(30502017, 'roslynne.amoah', 'Roslynne', 'Amoah', 'Female', 'NHIS', '1995/03/04', 260987345, 'Ghanaian', 2017, 'roslynne.amoah@ashesi.edu.gh', NULL),
(33952016, 'joana.campbell', 'Joanna', 'Campbell', 'Female', 'MED X', '1992/07/05', 247856385, 'American', 2016, 'joana.campbell@ashesi.edu.gh', NULL),
(43542018, 'neyo.mwesigwa', 'Neyo', 'Mwesigwa', 'Male', 'MED X', '1995/05/07', 245698567, 'Kenyan', 2018, 'neyo.mwesigwa@ashesi.edu.gh', NULL),
(60702017, 'jesse.akosa', '`Jesse', 'Akosa', 'Male', 'NHIS', '1993/02/02', 208456737, 'Ghanaian', 2017, 'jesse.akosa@ashesi.edu.gh', 0),
(88092017, 'ayishetu.seidu', 'Ayishetu', 'Seidu', 'Female', 'NHIS', '1992/05/06', 576903456, 'Ghanaian', 2017, 'ayishetu.seidu@ashesi.edu.gh', NULL),
(90092017, 'francis.yinbil', 'Francis', 'Yinbil', 'Male', 'NHIS', '1991/09/08', 549876543, 'Ghanaian', 2017, 'francis.yinbil@ashesi.edu.gh', NULL),
(98342016, 'henry.owusu', 'Henry', 'Owusu', 'Male', 'NHIS', '1992/09/03', 268097456, 'Ghanaian', 2016, 'henry.owusu@ashesi.edu.gh', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
