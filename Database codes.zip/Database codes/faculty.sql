-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2016 at 11:33 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `department` varchar(30) NOT NULL,
  `phone_number` int(30) NOT NULL,
  `insuranceType` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `facultyPatient_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `username`, `firstname`, `lastname`, `gender`, `dateOfBirth`, `department`, `phone_number`, `insuranceType`, `nationality`, `email`, `facultyPatient_id`) VALUES
('AUE000012', 'kajsa.adu', 'Kajsa', 'Adu', 'Female', '1867-09-03', 'Arts and Sciences', 245678907, 'MED X', 'Swedish', 'kajsa.adu@ashesi.edu.gh', NULL),
('AUE000049', 'joe.mensah', 'Joe', 'Mensah', 'Male', '1895-09-05', 'Business Administration', 502345689, 'MED X', 'Ghanaian', 'joe.mensah@ashesi.edu.gh', NULL),
('AUE000056', 'aelaf.dafla', 'Aelaf', 'Dafla', 'Male', '1880-12-05', 'Computer Science', 203456789, 'MED X', 'Eritrean', 'aelaf.dafla@ashesi.edu.gh', NULL),
('AUE000067', 'esi.ansah', 'Esi', 'Ansah', 'Female', '1890-09-07', 'Arts and Sciences', 245678908, 'NHIS', 'Ghanaian', 'esi.ansah@ashesi.edu.gh', NULL),
('AUE000078', 'ayorkor.korsah', 'Gertrude', 'Korsah', 'Female', '1892-09-12', 'Computer Science', 209876543, 'NHIS', 'Ghanaian', 'ayorkor.korsah2ashesi.edu.gh', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
