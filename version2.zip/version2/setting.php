<?php
define("DB_HOST","localhost");
define("DB_USERNAME","root");
define("DB_PASSWORD","C5ZQ3E6CBKTH");
define("DB_NAME","webtech");
?>